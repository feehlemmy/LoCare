package locare.controller;

import locare.model.entity.Profissional;
import locare.model.service.ProfissionalService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ProfissionalController {
    @RequestMapping(value = "/profissional/create", method = RequestMethod.GET)
    public ModelAndView getForm(){
        ModelAndView mv = new ModelAndView("formularioProfissional");
        return mv;
    }
    
    @RequestMapping(value = "/profissional/create", method = RequestMethod.POST)
    public ModelAndView create(Profissional profissional){
        ModelAndView mv = null;
        try {
            ProfissionalService service = new ProfissionalService();
            service.create(profissional);
            mv = new ModelAndView("redirect:/");
        } catch (Exception e){
            mv = new ModelAndView("error");
        }
        return mv;
    }
    
    @RequestMapping(value = "/profissional/{cpf}/update", method = RequestMethod.GET)
    public ModelAndView getFormForUpdate(@PathVariable String cpf) {
        ModelAndView mv = null;
        try {
            ProfissionalService service = new ProfissionalService();
            Profissional profissional = service.readByCpf(cpf);
            mv = new ModelAndView("formularioProfissional");
            mv.addObject("profissional", profissional);
        } catch (Exception ex) {
            mv = new ModelAndView("error");
        }
        return mv;
    }
    
    @RequestMapping(value = "/profissional/{cpf}/update", method = RequestMethod.POST)
    public ModelAndView update(@PathVariable String cpf, Profissional profissional) {
        ModelAndView mv = null;
        try {
            ProfissionalService service = new ProfissionalService();
            service.update(profissional);
            mv = new ModelAndView("redirect:/");
        } catch (Exception ex) {
            mv = new ModelAndView("error");
        }
        return mv;
    }
    

    @RequestMapping(value = "/profissional/{cpf}/delete", method = RequestMethod.GET)
    public ModelAndView delete(@PathVariable String cpf) {
        ModelAndView mv = null;
        try {
            ProfissionalService service = new ProfissionalService();
            service.delete(cpf);
            mv = new ModelAndView("redirect:/");
        } catch (Exception ex) {
            mv = new ModelAndView("error");
        }
        return mv;
    }
}
