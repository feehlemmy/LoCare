package locare.controller;

import locare.model.entity.Contratante;
import locare.model.service.ContratanteService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ContratanteController {
    @RequestMapping(value = "/contratante/create", method = RequestMethod.GET)
    public ModelAndView getForm(){
        ModelAndView mv = new ModelAndView("formularioContratante");
        return mv;
    }
    
    @RequestMapping(value = "/contratante/create", method = RequestMethod.POST)
    public ModelAndView create(Contratante contratante){
        ModelAndView mv = null;
        try {
            ContratanteService service = new ContratanteService();
            service.create(contratante);
            mv = new ModelAndView("redirect:/");
        } catch (Exception e) {
            mv = new ModelAndView("error");
        }
        return mv;
    }

    @RequestMapping(value = "/contratante/{cpf}/update", method = RequestMethod.GET)
    public ModelAndView getFormForUpdate(@PathVariable String cpf) {
        ModelAndView mv = null;
        try {
            ContratanteService service = new ContratanteService();
            Contratante contratante = service.readByCpf(cpf);
            mv = new ModelAndView("formularioContratante");
            mv.addObject("contratante", contratante);
        } catch (Exception ex) {
            mv = new ModelAndView("error");
        }
        return mv;
    }
    
    @RequestMapping(value = "/contratante/{cpf}/update", method = RequestMethod.POST)
    public ModelAndView update(@PathVariable String cpf, Contratante contratante) {
        ModelAndView mv = null;
        try {
            ContratanteService service = new ContratanteService();
            service.update(contratante);
            mv = new ModelAndView("redirect:/");
        } catch (Exception ex) {
            mv = new ModelAndView("error");
        }
        return mv;
    }
    

    @RequestMapping(value = "/contratante/{cpf}/delete", method = RequestMethod.GET)
    public ModelAndView delete(@PathVariable String cpf) {
        ModelAndView mv = null;
        try {
            ContratanteService service = new ContratanteService();
            service.delete(cpf);
            mv = new ModelAndView("redirect:/");
        } catch (Exception ex) {
            mv = new ModelAndView("error");
        }
        return mv;
    }
}
