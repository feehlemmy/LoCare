package locare.controller;

import java.util.List;
import locare.model.entity.Contratante;
import locare.model.entity.Profissional;
import locare.model.service.ContratanteService;
import locare.model.service.ProfissionalService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author gabriel
 */

@Controller
public class ListaContratanteController {
    
    
    @RequestMapping(value = "/listaContratante", method = RequestMethod.GET)
    public ModelAndView getListContratante() {
        ModelAndView mv = null;
        try {
            ContratanteService service = new ContratanteService();
            List<Contratante> contratanteList = service.read();
            mv = new ModelAndView("lista");
            mv.addObject("contratanteList", contratanteList);
        } catch (Exception ex) {
            mv = new ModelAndView("error");
        }
        return mv;
    }
}
