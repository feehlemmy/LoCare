package locare.model.service;

import java.util.ArrayList;
import java.util.List;
import locare.model.entity.Contratante;

/**
 *
 * @author gabriel
 */
public class ContratanteService {
    private static List<Contratante> contratanteList = new ArrayList<>();
    
    public void create(Contratante contratante) throws Exception{
        contratante.setCpf(contratante.getCpf());
        contratanteList.add(contratante);
    }
    
    public Contratante readByCpf(String cpf) throws Exception{
        Contratante contratante = null;
        for(Contratante aux : contratanteList){
            if(aux.getCpf().equals(cpf)){
                contratante = aux;
                break;
            }
        }
        return contratante;
    }
    
    public List<Contratante> read() throws Exception{
        return contratanteList;
    }
    
    public void update(Contratante contratante) throws Exception{
        for(Contratante aux : contratanteList){
            if(aux.getCpf().equals(contratante.getCpf())) {
                aux.setCpf(contratante.getCpf());
                aux.setNome(contratante.getNome());
                aux.setDataNascimento(contratante.getDataNascimento());
                aux.setTelefone(contratante.getTelefone());
                aux.setEmailContratante(contratante.getEmailContratante());
                aux.setSenhaContratante(contratante.getSenhaContratante());
                aux.setLogradouro(contratante.getLogradouro());
                aux.setCep(contratante.getCep());
                aux.setBairro(contratante.getBairro());
                aux.setCidade(contratante.getCidade());
                aux.setNumeroCartao(contratante.getNumeroCartao());
                
                break;
            }
        }
    }
    
    public void delete(String cpf){
        for(Contratante aux : contratanteList){
            if(aux.getCpf().equals(cpf)){
                contratanteList.remove(aux);
                break;
            }
        }
    }
}
