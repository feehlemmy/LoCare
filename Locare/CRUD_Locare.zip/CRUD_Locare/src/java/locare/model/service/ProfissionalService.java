package locare.model.service;

import java.util.ArrayList;
import java.util.List;
import locare.model.entity.Profissional;

/**
 *
 * @author gabriel
 */
public class ProfissionalService {
    private static List<Profissional> profissionalList = new ArrayList<>();
    
    public void create(Profissional profissional) throws Exception{
        profissional.setCpf(profissional.getCpf());
        profissionalList.add(profissional);
    }
    
    public Profissional readByCpf(String cpf) throws Exception{
        Profissional profissional = null;
        for(Profissional aux : profissionalList){
            if(aux.getCpf().equals(cpf)){
                profissional = aux;
                break;
            }
        }
        return profissional;
    }
    
    public List<Profissional> read() throws Exception{
        return profissionalList;
    }
    
    public void update(Profissional profissional) throws Exception{
        for(Profissional aux : profissionalList){
            if(aux.getCpf().equals(profissional.getCpf())){
                aux.setCpf(profissional.getCpf());
                aux.setNome(profissional.getNome());
                aux.setTelefone(profissional.getTelefone());
                aux.setDataNascimento(profissional.getDataNascimento());
                aux.setLogradouro(profissional.getLogradouro());
                aux.setCidade(profissional.getCidade());
                aux.setCep(profissional.getCep());
                aux.setBairro(profissional.getBairro());
                
                aux.setEmailProfissional(profissional.getEmailProfissional());
                aux.setSenhaProfissional(profissional.getSenhaProfissional());
                aux.setNumeroRegistro(profissional.getNumeroRegistro());
                aux.setDataFormacao(profissional.getDataFormacao());
                aux.setFormacao(profissional.getFormacao());

                break;
            }
        }
    }
    
    public void delete(String cpf) throws Exception{
        for(Profissional aux : profissionalList){
            if(aux.getCpf().equals(cpf)){
                profissionalList.remove(aux);
                break;
            }
        }
    }
}
