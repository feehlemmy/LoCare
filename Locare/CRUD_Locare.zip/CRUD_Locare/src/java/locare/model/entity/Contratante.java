package locare.model.entity;

public class Contratante extends Pessoa{
    private String emailContratante;
    private String senhaContratante;
    private Long numeroCartao;

    public String getEmailContratante() {
        return emailContratante;
    }

    public void setEmailContratante(String emailContratante) {
        this.emailContratante = emailContratante;
    }

    public String getSenhaContratante() {
        return senhaContratante;
    }

    public void setSenhaContratante(String senhaContratante) {
        this.senhaContratante = senhaContratante;
    }

    public Long getNumeroCartao() {
        return numeroCartao;
    }

    public void setNumeroCartao(Long numeroCartao) {
        this.numeroCartao = numeroCartao;
    }
        
}
