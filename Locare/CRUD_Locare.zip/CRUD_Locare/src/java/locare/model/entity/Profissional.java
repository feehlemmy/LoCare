package locare.model.entity;

import java.util.Date;

public class Profissional extends Pessoa{
    private String emailProfissional;
    private String senhaProfissional;
    private String numeroRegistro;
    //private String ufRegistro;
    private Date dataFormacao;
    private String formacao;
    //private String avaliacao;
    //private Double valorHora;

    public String getEmailProfissional() {
        return emailProfissional;
    }

    public void setEmailProfissional(String emailProfissional) {
        this.emailProfissional = emailProfissional;
    }

    public String getSenhaProfissional() {
        return senhaProfissional;
    }

    public void setSenhaProfissional(String senhaProfissional) {
        this.senhaProfissional = senhaProfissional;
    }

    public String getNumeroRegistro() {
        return numeroRegistro;
    }

    public void setNumeroRegistro(String numeroRegistro) {
        this.numeroRegistro = numeroRegistro;
    }

    /*
    public String getUfRegistro() {
        return ufRegistro;
    }

    public void setUfRegistro(String ufRegistro) {
        this.ufRegistro = ufRegistro;
    }*/

    public Date getDataFormacao() {
        return dataFormacao;
    }

    public void setDataFormacao(Date dataFormacao) {
        this.dataFormacao = dataFormacao;
    }

    public String getFormacao() {
        return formacao;
    }

    public void setFormacao(String formacao) {
        this.formacao = formacao;
    }
    
    /*
    public String getAvaliacao() {
        return avaliacao;
    }

    public void setAvaliacao(String avaliacao) {
        this.avaliacao = avaliacao;
    }
    
    public Double getValorHora() {
        return valorHora;
    }

    public void setValorHora(Double valorHora) {
        this.valorHora = valorHora;
    }*/
}
